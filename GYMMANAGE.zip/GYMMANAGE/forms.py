from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Length, Regexp

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[
        DataRequired(message="Username is required"),
        Length(min=2, max=25, message="Username must be between 2 and 25 characters"),
        Regexp('^[A-Za-z0-9_]+$', message="Username must contain only letters, numbers, and underscores")
    ])
    password = PasswordField('Password', validators=[
        DataRequired(message="Password is required"),
        Length(min=6, message="Password must be at least 6 characters long")
    ])
    submit = SubmitField('Login')

class MemberForm(FlaskForm):
    name = StringField('Name', validators=[
        DataRequired(message="Name is required"),
        Length(min=2, max=50, message="Name must be between 2 and 50 characters")
    ])
    status = StringField('Status', validators=[
        DataRequired(message="Status is required"),
        Length(min=2, max=20, message="Status must be between 2 and 20 characters")
    ])
    submit = SubmitField('Add Member')